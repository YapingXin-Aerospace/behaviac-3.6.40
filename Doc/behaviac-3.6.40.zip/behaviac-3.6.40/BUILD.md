## 首先从[github](https://github.com/TencentOpen/behaviac)下载或克隆源码。

----------------
## 访问[build](http://www.behaviac.com/docs/zh/articles/build/)获取编译指引

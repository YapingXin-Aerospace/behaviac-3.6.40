﻿using System;
using System.Collections;

[behaviac.TypeMetaInfo()]
public class HTNAgentHouseBase : behaviac.Agent
{
    //[behaviac.MemberMetaInfo("", "MemberProperty")]
    //public int Money = 0;

    //methods
    [behaviac.MethodMetaInfo()]
    public void ObtainPermit() {
    }
}

﻿using System;
using System.Collections;

[behaviac.TypeMetaInfo()]
public class HTNAgentHouse : HTNAgentHouseBase
{
    public void resetProperties() {
    }

    public void init() {
        base.Init();

        resetProperties();
    }

    public void finl() {
    }


    //[behaviac.MemberMetaInfo("", "")]
    //public bool Land = false;

    ////tasks
    //[behaviac.MethodMetaInfo()]
    //public void root()
    //{
    //}

    //[behaviac.MethodMetaInfo()]
    //public void build_house()
    //{
    //}

    //[behaviac.MethodMetaInfo()]
    //public void construct()
    //{
    //}


    [behaviac.MethodMetaInfo()]
    public void HireBuilder() {
    }

    [behaviac.MethodMetaInfo()]
    public void PayBuilder() {
    }

    [behaviac.MethodMetaInfo()]
    public void BuildFoundation() {
    }

    [behaviac.MethodMetaInfo()]
    public void BuildFrame() {
    }

    [behaviac.MethodMetaInfo()]
    public void BuildRoof() {
    }

    [behaviac.MethodMetaInfo()]
    public void BuildWalls() {
    }

    [behaviac.MethodMetaInfo()]
    public void BuildInterior() {
    }

    [behaviac.MethodMetaInfo()]
    public void CutLogs() {
    }

    [behaviac.MethodMetaInfo()]
    public void GetFriend() {
    }

    [behaviac.MethodMetaInfo()]
    public void BuyLand() {
    }

    [behaviac.MethodMetaInfo()]
    public void GetLoan() {
    }
}
